function calcularSoma() {
  var soma = 0;
  for (var i = 1; i <= 18; i++) {
    var selectId = "select" + i;
    var select = document.getElementById(selectId);
    var valorSelecionado = parseInt(select.value);
    soma += valorSelecionado;
  }
  
  var resultadoElement = document.getElementById("resultado");
  resultadoElement.textContent = "Seu total de pontos é: " + soma;
  var comparativo = "";
  if (soma <= 150) {
    comparativo = "É menor que 4 gha, equivalente à dos E.U.A.";
  } else if (soma <= 400) {
    comparativo = "Está entre 4 e 6 gha, equivalente à da França";
  } else if (soma <= 600) {
    comparativo = "Está entre 6 e 8 gha, equivalente à da Suécia";
  } else if (soma <= 800) {
    comparativo = "Está entre 8 e 10 gha, padrão Brasil";
  } else {
    comparativo = "É maior que 10 gha, dentro da média mundial";
  }
  
  alert("Seu total de pontos é: " + soma + "\nPegada ecológica: " + comparativo);
}
  

